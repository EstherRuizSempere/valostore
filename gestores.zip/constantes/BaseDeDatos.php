<?php
class BaseDeDatos {
    public static $host = "sql211.infinityfree.com";
    public static $db = "if0_38176056_valostore";
    public static $user = "if0_38176056";
    public static $password = "planetterror12";
}
