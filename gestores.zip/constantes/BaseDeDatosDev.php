<?php
class BaseDeDatos {
    public static $host = "localhost:3306";
    public static $db = "valostore";
    public static $user = "root";
    public static $password = "";
}
